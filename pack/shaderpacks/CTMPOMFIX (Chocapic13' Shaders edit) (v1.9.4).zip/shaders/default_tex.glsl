	//check for blank _s or _n texture
	#if DEBUG_GEN_NORMAL_MAP == 1
		//check for blank _s or _n texture
		data0.rgb=(specular_target==vec4(S_BLANK_R , S_BLANK_G , S_BLANK_B , S_BLANK_A ))?  vec3(1.0,0.0,0.0) : data0.rgb;
		#if GEN_NORMAL_MAP == 1
		if ( abs(normal_map.r - N_BLANK_R )+abs(normal_map.g - N_BLANK_G )+abs(normal_map.b - N_BLANK_B )+abs(normal_map.a - N_BLANK_A ) < 5.0/255.0)
		{
		data0.rgb=vec3(0.0,1.0,0.0) ;
		}
		#else
		//normal_map=(normal_map==vec4(N_BLANK_R , N_BLANK_G , N_BLANK_B , N_BLANK_A ))?  vec4(0.5,0.5,1.0,1.0) : normal_map;
		#endif
	#else
		//check for blank _s or _n texture
		//specular_target= ( specular_target == vec4( S_BLANK_R , S_BLANK_G , S_BLANK_B , S_BLANK_A )) ?  vec4(0.0,0.04,0.0,0.0) : specular_target;
		#if GEN_NORMAL_MAP == 1
		if ( abs(normal_map.r - N_BLANK_R )+abs(normal_map.g - N_BLANK_G )+abs(normal_map.b - N_BLANK_B )+abs(normal_map.a - N_BLANK_A ) < 5.0/255.0)
		{
		normal_map=vec4( 0.5+sin(vtexcoord.s*33) *.005,0.5+sin(vtexcoord.t*33)*.005,1.0,1.0);
		//data0.rgb=normal_map.rgb;
		}
		#else
		//normal_map=(normal_map==vec4(N_BLANK_R , N_BLANK_G , N_BLANK_B , N_BLANK_A ))?  vec4(0.5,0.5,1.0,1.0) : normal_map;
		#endif
	#endif