// © Copyright 2023 timetravelbeard (contact: https://www.patreon.com/timetravelbeard , https://youtube.com/@timetravelbeard3588 , https://discord.gg/S6F4r6K5yU )

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT  TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

//NOTE:  In case you don't know, copyright means all rights are reserved. You cannot modify, redistribute, or make derivative works of this. Do not steal any of this code or use "code snippets". 

//uniform float frameTimeCounter;

//fractn1(sin(















				 //make cone
		
			      #if RAY_FULLY_CONVERGE == 1
				  for(int ri = 0;ri<2;ri++)
				  {
				  if(ri == 0)
				  {
				  rayspeed=goal;
				  }else{
				  #endif
			 
			     
				 for(int s =0 ;s<4;s++)
				 {
				 	switch(s)
				 {
				 	case 0:
				 t1 = tangent.xyz;
				 t2 = tangent2.xyz;
				 break;
				 case 1:
				 t1 = -tangent.xyz;
				 t2 = tangent2.xyz;
				 break;
				 case 2:
				 t1 = -tangent.xyz;
				 t2 = -tangent2.xyz;
				 break;
				 case 3:
				 t1 = tangent.xyz;
				 t2 = -tangent2.xyz;
				 break;
				 }
				 for(int y =0 ;y<h;y++)
				 {
				 	float hrot = mix(focus,1.0,y*ih
					#if RAY_STAGGER_TYPE == 1
						+ih*fract(sin(mod(frameTimeCounter,10.)*100.+texcoord.x*5124.+texcoord.y*714.))//rayynoise
					#endif
					);
				 	for(int x =0 ;x<w;x++)
				 {
				 
				  float wrot = x*iw
				 #if RAY_STAGGER_TYPE == 1
					+iw*fract(sin(mod(frameTimeCounter,10.)*100.+texcoord.x*5124.+texcoord.y*714.))//rayxnoise //random(float(worldTime))
				 #endif
				 ;
		
				 rayspeed = mix( mix(t1, t2, wrot) , goal , hrot);
				 
				 
				
			
				 
				 
				 
// © Copyright 2023 timetravelbeard (contact: https://www.patreon.com/timetravelbeard , https://youtube.com/@timetravelbeard3588 , https://discord.gg/S6F4r6K5yU )

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT  TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

//NOTE:  In case you don't know, copyright means all rights are reserved. You cannot modify, redistribute, or make derivative works of this. Do not steal any of this code or use "code snippets". 
