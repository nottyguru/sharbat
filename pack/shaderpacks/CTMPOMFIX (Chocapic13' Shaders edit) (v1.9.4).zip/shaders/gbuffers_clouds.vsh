#version 120

varying vec2 texcoord;
varying vec4 glcolor;

#define HELP_INFO 0 //[0 1]
#define HELP_INFO2 0 //[0 1]

void main() {
	gl_Position = ftransform();
	gl_Position.z= 10.;
	#if VANILLA_CLOUDS == 0 || CLOUD_STYLE >=5
		gl_Position.z= 10.;
	#endif
	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
	glcolor = gl_Color;
}