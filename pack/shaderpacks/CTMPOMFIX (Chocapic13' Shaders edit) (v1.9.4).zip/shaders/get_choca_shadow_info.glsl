//<<this bit is chocapic13's to deal with thier stuff
		vec4 data = texture2D(colortex1,raypos.xy);
		vec4 dataUnpacked0 = vec4(decodeVec2(data.x),decodeVec2(data.y));
		vec4 dataUnpacked1 = vec4(decodeVec2(data.z),decodeVec2(data.w));
       
		
		vec3 albedo2 = toLinear(vec3(dataUnpacked0.xz,dataUnpacked1.x));
		//if (luma(albedo) < 0.15) albedo = vec3(1.0,0.,0.);
		vec3 normal2 = mat3(gbufferModelViewInverse) * decode(dataUnpacked0.yw);




	//vec3 fragpos0 = toScreenSpace(vec3(texcoord/RENDER_SCALE-vec2(tempOffset)*texelSize*0.5,z0));
				vec3 projectedShadowPosition = mat3(shadowModelView) * ppp + shadowModelView[3].xyz;
			projectedShadowPosition = diagonal3(shadowProjection) * projectedShadowPosition + shadowProjection[3].xyz;
			//apply distortion
			float distortFactor = calcDistort(projectedShadowPosition.xy);
			projectedShadowPosition.xy *= distortFactor;
			projectedShadowPosition=projectedShadowPosition* vec3(0.5,0.5,0.5/6.0) + vec3(0.5,0.5,0.5);
			vec4 shadow_info = vec4(0.0);
			//do shadows only if on shadow map
			if (abs(projectedShadowPosition.x) < 1.0-1.5/shadowMapResolution && abs(projectedShadowPosition.y) < 1.0-1.5/shadowMapResolution && abs(projectedShadowPosition.z) < 6.0)
			
			 //>>end chocapic13 stuff 