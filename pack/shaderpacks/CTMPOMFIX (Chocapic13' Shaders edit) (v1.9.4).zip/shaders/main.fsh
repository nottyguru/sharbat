#version 120
#extension GL_EXT_gpu_shader4 : enable
#extension GL_ARB_shader_texture_lod : enable

uniform vec3 upPosition;

uniform vec3 sunPosition;

#define POM
#define Depth_Write_POM	// POM adjusts the actual position, so screen space shadows can cast shadows on POM
#define POM_DEPTH 0.15 // [0.025 0.05 0.075 0.1 0.125 0.15 0.20 0.25 0.30 0.50 0.75 1.0] //Increase to increase POM strength
#define MAX_ITERATIONS 50 // [5 10 15 20 25 30 40 50 60 70 80 90 100 125 150 200 400] //Improves quality at grazing angles (reduces performance)
#define MAX_DIST 25.0 // [5.0 10.0 15.0 20.0 25.0 30.0 40.0 50.0 60.0 70.0 80.0 90.0 100.0 125.0 150.0 200.0 400.0] //Increases distance at which POM is calculated
//#define AutoGeneratePOMTextures	//Can generate POM on any texturepack (may look weird in some cases)
#define Texture_MipMap_Bias -1.00 // Uses a another mip level for textures. When reduced will increase texture detail but may induce a lot of shimmering. [-5.00 -4.75 -4.50 -4.25 -4.00 -3.75 -3.50 -3.25 -3.00 -2.75 -2.50 -2.25 -2.00 -1.75 -1.50 -1.25 -1.00 -0.75 -0.50 -0.25 0.00 0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.25 2.50 2.75 3.00 3.25 3.50 3.75 4.00 4.25 4.50 4.75 5.00]
//#define DISABLE_ALPHA_MIPMAPS //Disables mipmaps on the transparency of alpha-tested things like foliage, may cost a few fps in some cases
#ifndef AutoGeneratePOMTextures
#ifndef MC_NORMAL_MAP
#undef POM
#endif
#endif

#ifdef POM
#define MC_NORMAL_MAP
#endif

const float mincoord = 1.0/4096.0;
const float maxcoord = 1.0-mincoord;

const float MAX_OCCLUSION_DISTANCE = MAX_DIST;
const float MIX_OCCLUSION_DISTANCE = MAX_DIST*0.9;
const int   MAX_OCCLUSION_POINTS   = MAX_ITERATIONS;

uniform vec2 texelSize;
#ifdef POM
varying vec4 vtexcoordam; // .st for add, .pq for mul
varying vec4 vtexcoord;

uniform int framemod8;
#endif
#include "/lib/res_params.glsl"
varying vec4 lmtexcoord;
varying vec4 color;
varying vec4 normalMat;
#ifdef MC_NORMAL_MAP
varying vec4 tangent;
varying vec4 wtangent;
uniform float wetness;
uniform sampler2D normals;
uniform sampler2D specular;
#endif
#ifdef POM
vec2 dcdx = dFdx(vtexcoord.st*vtexcoordam.pq)*exp2(Texture_MipMap_Bias);
vec2 dcdy = dFdy(vtexcoord.st*vtexcoordam.pq)*exp2(Texture_MipMap_Bias);
#endif
uniform sampler2D texture;
uniform float frameTimeCounter;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferProjection;
float interleaved_gradientNoise(){
	return fract(52.9829189*fract(0.06711056*gl_FragCoord.x + 0.00583715*gl_FragCoord.y)+frameTimeCounter*51.9521);
}
mat3 inverse(mat3 m) {
  float a00 = m[0][0], a01 = m[0][1], a02 = m[0][2];
  float a10 = m[1][0], a11 = m[1][1], a12 = m[1][2];
  float a20 = m[2][0], a21 = m[2][1], a22 = m[2][2];

  float b01 = a22 * a11 - a12 * a21;
  float b11 = -a22 * a10 + a12 * a20;
  float b21 = a21 * a10 - a11 * a20;

  float det = a00 * b01 + a01 * b11 + a02 * b21;

  return mat3(b01, (-a22 * a01 + a02 * a21), (a12 * a01 - a02 * a11),
              b11, (a22 * a00 - a02 * a20), (-a12 * a00 + a02 * a10),
              b21, (-a21 * a00 + a01 * a20), (a11 * a00 - a01 * a10)) / det;
}


#ifdef MC_NORMAL_MAP
vec3 applyBump(mat3 tbnMatrix, vec3 bump)
{

		float bumpmult = 1.0-wetness*0.95;

		bump = bump * vec3(bumpmult, bumpmult, bumpmult) + vec3(0.0f, 0.0f, 1.0f - bumpmult);

		return normalize(bump*tbnMatrix);
}
#endif

//encoding by jodie
float encodeVec2(vec2 a){
    const vec2 constant1 = vec2( 1., 256.) / 65535.;
    vec2 temp = floor( a * 255. );
	return temp.x*constant1.x+temp.y*constant1.y;
}
float encodeVec2(float x,float y){
    return encodeVec2(vec2(x,y));
}

#define diagonal3(m) vec3((m)[0].x, (m)[1].y, m[2].z)
#define  projMAD(m, v) (diagonal3(m) * (v) + (m)[3].xyz)
vec3 toScreenSpace(vec3 p) {
	vec4 iProjDiag = vec4(gbufferProjectionInverse[0].x, gbufferProjectionInverse[1].y, gbufferProjectionInverse[2].zw);
    vec3 p3 = p * 2. - 1.;
    vec4 fragposition = iProjDiag * p3.xyzz + gbufferProjectionInverse[3];
    return fragposition.xyz / fragposition.w;
}
vec3 toClipSpace3(vec3 viewSpacePosition) {
    return projMAD(gbufferProjection, viewSpacePosition) / -viewSpacePosition.z * 0.5 + 0.5;
}


float sky_reflection;



vec4 encode_cpf (vec3 n)
{

    return vec4(n.xy*inversesqrt(n.z*8.0+8.0) + 0.5,vec2(lmtexcoord.z,lmtexcoord.w));
}

vec4 encode_cpfw(vec3 n)
{//encode sky reflection amount
  //return vec4(n.xy*inversesqrt(n.z*8.0+8.0) + 0.5,vec2(lmtexcoord.z,lmtexcoord.w));
    return vec4(n.xy*inversesqrt(n.z*8.0+8.0) + 0.5,vec2(lmtexcoord.z,sky_reflection));
	
}

	varying float sky_exposure_cpf;
//encode normal in two channels (xy),torch(z) and sky lightmap (w)
vec4 encode (vec3 n)
{
  //return vec4(n.xy*inversesqrt(n.z*8.0+8.0) + 0.5,vec2(lmtexcoord.z,sky_reflection*15));
   return vec4(n.xy*inversesqrt(n.z*8.0+8.0) + 0.5,vec2(lmtexcoord.z,lmtexcoord.w));
	
}

float pom_depth_forward;
#define CAPTURE_CPF_POM_DEPTH 1

#ifdef POM


	#include "/ctmpomfix.glsl"
	


	
vec4 readNormal(in vec2 coord)
{
	return texture2DGradARB(normals,fract(coord)*vtexcoordam.pq+vtexcoordam.st,dcdx,dcdy);
}
vec4 readTexture(in vec2 coord)
{
	return texture2DGradARB(texture,fract(coord)*vtexcoordam.pq+vtexcoordam.st,dcdx,dcdy);
}
#endif
float luma(vec3 color) {
	return dot(color,vec3(0.21, 0.72, 0.07));
}


vec3 toLinear(vec3 sRGB){
	return sRGB * (sRGB * (sRGB * 0.305306011 + 0.682171111) + 0.012522878);
}


const vec2[8] offsets = vec2[8](vec2(1./8.,-3./8.),
									vec2(-1.,3.)/8.,
									vec2(5.0,1.)/8.,
									vec2(-3,-5.)/8.,
									vec2(-5.,5.)/8.,
									vec2(-7.,-1.)/8.,
									vec2(3,7.)/8.,
									vec2(7.,-7.)/8.);
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////


varying vec3 relative_position;
/*
const int colortex15Format = RGBA32F;
*/
/* RENDERTARGETS: 1,9,11,12,14,15,10 */
void main() {
	float noise = interleaved_gradientNoise();
	vec3 normal = normalMat.xyz;
	#ifdef MC_NORMAL_MAP
		vec3 tangent2 = normalize(cross(tangent.rgb,normal)*tangent.w);
		mat3 tbnMatrix = mat3(tangent.x, tangent2.x, normal.x,
								  tangent.y, tangent2.y, normal.y,
						     	  tangent.z, tangent2.z, normal.z);
	#endif

#ifdef POM
vec2 tempOffset=offsets[framemod8];
vec2 adjustedTexCoord = fract(vtexcoord.st)*vtexcoordam.pq+vtexcoordam.st;
vec3 fragpos = toScreenSpace(gl_FragCoord.xyz*vec3(texelSize/RENDER_SCALE,1.0)-vec3(vec2(tempOffset)*texelSize*0.5,0.0));
vec3 viewVector = normalize(tbnMatrix*fragpos);
float dist = length(fragpos);


vec4 data0;
vec4 normal_map;
vec4 specular_target;

#if CTMPOMFIX == 1
	#if TEXTURE_FILTERING_CPF == 9
		Ctmpomfix_alt_pom_as_insert_for_coords( dist, vtexcoord, viewVector, adjustedTexCoord, noise);
	#else
		//Ctmpomfix_alt_pom_as_insert_for_coords( dist, vtexcoord, viewVector, adjustedTexCoord, noise);
		Ctmpomfix_alt_pom_as_insert_for_texture_data( dist, vtexcoord, viewVector, adjustedTexCoord, noise,data0,normal_map, specular_target);
	#endif
#else


#ifdef Depth_Write_POM
gl_FragDepth = gl_FragCoord.z;
#endif
if (dist < MAX_OCCLUSION_DISTANCE) {
  #ifndef AutoGeneratePOMTextures
    if ( viewVector.z < 0.0 && readNormal(vtexcoord.st).a < 0.9999 && readNormal(vtexcoord.st).a > 0.00001) {
      vec3 interval = viewVector.xyz /-viewVector.z/MAX_OCCLUSION_POINTS*POM_DEPTH;
      vec3 coord = vec3(vtexcoord.st, 1.0);
      coord += noise*interval;
			float sumVec = noise;
      for (int loopCount = 0;
          (loopCount < MAX_OCCLUSION_POINTS) && (1.0 - POM_DEPTH + POM_DEPTH*readNormal(coord.st).a < coord.p) &&coord.p >= 0.0;
          ++loopCount) {
               coord = coord+interval;
							 sumVec += 1.0;
      }
      if (coord.t < mincoord) {
        if (readTexture(vec2(coord.s,mincoord)).a == 0.0) {
          coord.t = mincoord;
          discard;
        }
      }
      adjustedTexCoord = mix(fract(coord.st)*vtexcoordam.pq+vtexcoordam.st , adjustedTexCoord , max(dist-MIX_OCCLUSION_DISTANCE,0.0)/(MAX_OCCLUSION_DISTANCE-MIX_OCCLUSION_DISTANCE));

      vec3 truePos = fragpos + sumVec*inverse(tbnMatrix)*interval;
      #ifdef Depth_Write_POM
      gl_FragDepth = toClipSpace3(truePos).z;
      #endif
    }
  #else
	if ( viewVector.z < 0.0) {
		vec3 interval = viewVector.xyz/-viewVector.z/MAX_OCCLUSION_POINTS*POM_DEPTH;
		vec3 coord = vec3(vtexcoord.st, 1.0);
		coord += noise*interval;
		float sumVec = noise;
		float lum0 = luma(texture2DLod(texture,lmtexcoord.xy,100).rgb);
    for (int loopCount = 0;
        (loopCount < MAX_OCCLUSION_POINTS) && (1.0 - POM_DEPTH + POM_DEPTH*luma(readTexture(coord.st).rgb)/lum0*0.5 < coord.p) && coord.p >= 0.0;
				++loopCount) {
						 coord = coord+interval;
						 sumVec += 1.0;
		}
		if (coord.t < mincoord) {
			if (readTexture(vec2(coord.s,mincoord)).a == 0.0) {
				coord.t = mincoord;
				discard;
			}
		}
		adjustedTexCoord = mix(fract(coord.st)*vtexcoordam.pq+vtexcoordam.st , adjustedTexCoord , max(dist-MIX_OCCLUSION_DISTANCE,0.0)/(MAX_OCCLUSION_DISTANCE-MIX_OCCLUSION_DISTANCE));

		vec3 truePos = fragpos + sumVec*inverse(tbnMatrix)*(interval);
		#ifdef Depth_Write_POM
		gl_FragDepth = toClipSpace3(truePos).z;
		#endif
	}
  #endif

  }
  
  	specular_target = texture2DGradARB(specular, adjustedTexCoord.xy,dcdx,dcdy);
	specular_target=specular_target=vec4(0.0)? vec4(0.0,0.04,0.0,0.0);
	
	normal_map=normal_map=vec4(0.0)? vec4(0.5,0.5,1.0,1.0);
    #endif
  //end if enable ctmpomfix or not
  
  #if CTMPOMFIX == 1 && TEXTURE_FILTERING_CPF != 0
	normal = applyBump(tbnMatrix,normal_map.xyz*2.-1.);

  #else

		data0 = texture2DGradARB(texture, adjustedTexCoord.xy,dcdx,dcdy);
		normal = applyBump(tbnMatrix,texture2DGradARB(normals,adjustedTexCoord.xy,dcdx,dcdy).xyz*2.-1.);
   #endif
   //end if enable ctmpomfix texture filtering or not

	
  #ifdef DISABLE_ALPHA_MIPMAPS
    data0.a = texture2DGradARB(texture, adjustedTexCoord.xy,vec2(0.),vec2(0.0)).a;
  #endif
	if (data0.a > 0.1) data0.a = normalMat.a;
  else data0.a = 0.0;


	


	data0.rgb*=color.rgb;
	#if PBR_QUALITY_CPF == 5
		//vec4 data1 = clamp(noise*exp2(-8.)+encode(normal),0.,1.0);
		//vec4 data1 = clamp(noise*exp2(-8.)+encode_cpf(normal),0.,1.0);
	#else
		//normal and lightmap
		vec4 data1 = clamp(noise*exp2(-8.)+encode(normal),0.,1.0);
		//instead, 
	#endif
	
	
	
		
		//sun occluded by face normal
		vec3 face_normals = normal_tex_to_view_cpf(vec3(0.5,0.5,1.0));
		//face_normals= (face_normals+1)*.5;
		
		
		
			//sky reflection angle
			//vec3 reflected_angle_face = reflect(normalize(sunPosition.xyz),face_normals); 
			//angle's reflectivity of sky
			float reflectivity_angle_face = clamp(.75*distance(-normalize(upPosition),face_normals.xyz),0.0,1.0);
			float reflectivity_angle_face_to_sun = clamp(1.-distance(normalize(sunPosition.xyz),face_normals)/1.42,0.,1.); 
			
			gl_FragData[3] = vec4(reflectivity_angle_face,sky_exposure_cpf,face_normals.z,reflectivity_angle_face_to_sun);
			//normal_tex_to_view_cpf()
			//sky_reflectivity_angle = reflectivity_angle_face <= 0.2 ? sky_reflectivity_angle * reflectivity_angle_face*5  : //sky_reflectivity_angle;
		
		


	vec3 face_normal_world = applyBump(tbnMatrix,vec3(0.5,0.5,1.0)*2.-1.);
	float o2 =dot(face_normal_world,normalize(upPosition));// 
	
	gl_FragData[2] =  vec4(.5+.5*normal_tex_to_view_cpf(vec3(1.0,0.5,0.5)),o2);//pom_depth_forward);
	gl_FragData[1] = specular_target;
	gl_FragData[0] = vec4(encodeVec2(data0.x,data1.x),encodeVec2(data0.y,data1.y),encodeVec2(data0.z,data1.z),encodeVec2(data1.w,data0.w));
	gl_FragData[4]  = vec4(.5+.5*normal_tex_to_view_cpf(normal_map.rgb),1.0);//1.0 temporarily means do pbr
	gl_FragData[5]  = (vec4(relative_position,sky_reflection*15));
	gl_FragData[6] = vec4(.5+.5*normal_tex_to_view_cpf(vec3(0.5,1.0,0.5)),1.0);
	//gl_FragData[3] = vec4(reflectivity_angle_face,sky_exposure_cpf,face_normals.z,face_normals.y);
	#else

	vec4 data0 = texture2D(texture, lmtexcoord.xy, Texture_MipMap_Bias);

	data0.rgb*=color.rgb;
  float avgBlockLum = luma(texture2DLod(texture, lmtexcoord.xy,128).rgb*color.rgb);
  data0.rgb = clamp(data0.rgb*pow(avgBlockLum,-0.33)*0.85,0.0,1.0);
  //data0.rgb = vec3(avgBlockLum);
  //data0.rgb = clamp(data0.rgb*pow((0.55+avgBlockLum),-(1.0/2.233)),0.0,1.0);
  //if (toLinear(data0.rgb).g > 0.25) data0.rgb=vec3(1.,0.,0.);
  #ifdef DISABLE_ALPHA_MIPMAPS
  data0.a = texture2DLod(texture,lmtexcoord.xy,0).a;
  #endif


	if (data0.a > 0.1) data0.a = normalMat.a;
  else data0.a = 0.0;
	#ifdef MC_NORMAL_MAP
	normal = applyBump(tbnMatrix,texture2D(normals, lmtexcoord.xy).rgb*2.-1.);
	#endif
	vec4 data1 = clamp(noise/256.+encode(normal),0.,1.0);

	gl_FragData[0] = vec4(encodeVec2(data0.x,data1.x),encodeVec2(data0.y,data1.y),encodeVec2(data0.z,data1.z),encodeVec2(data1.w,data0.w));
	#endif

}
