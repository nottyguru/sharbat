#version 120

uniform sampler2D texture;

varying vec2 texcoord;
varying vec4 glcolor;

void main() {
discard;
return;
#if VANILLA_CLOUDS == 0 || CLOUD_STYLE >=5
discard;
return;
vec4 color;
#else

	vec4 color = texture2D(texture, texcoord) * glcolor;


#endif
gl_FragData[0] = color; //gcolor
/* DRAWBUFFERS:0 */
	
}