#version 120
/* MakeUp - E-LITE shaders 5 - gbuffers_hand_water.vsh
Render: Translucent hand objects

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define THE_END
#define GBUFFER_HAND_WATER

#include "/common/solid_blocks_vertex.glsl"
