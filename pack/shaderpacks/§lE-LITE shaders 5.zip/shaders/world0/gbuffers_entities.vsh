#version 120
/* MakeUp - E-LITE shaders 5 - gbuffers_entities.vsh
Render: Droped objects, mobs and things like that

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define GBUFFER_ENTITIES
#define CAVEENTITY_V

#include "/common/solid_blocks_vertex.glsl"
