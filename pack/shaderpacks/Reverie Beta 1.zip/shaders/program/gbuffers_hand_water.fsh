#include "/lib/all_the_libs.glsl"

#include "/generic/water.glsl"
#include "/generic/shadow/main.glsl"
#include "/generic/lighting.fsh"
#include "/generic/gbuffers_translucent.fsh"

void main() {
    init_frag_translucent();
}
