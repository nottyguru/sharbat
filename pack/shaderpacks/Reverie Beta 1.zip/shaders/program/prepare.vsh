#include "/lib/all_the_libs.glsl"

void main() {
    if (gl_VertexID == 0) {
        dataBuf.SunColor = get_direct_color(false);
        dataBuf.MoonColor = get_direct_color(true);
    }
    else if (gl_VertexID == 1) {
        #ifdef DIMENSION_OVERWORLD
        dataBuf.AmbientColor = get_ambient_color();
        #endif
    }
    gl_Position = vec4(-1);
}
