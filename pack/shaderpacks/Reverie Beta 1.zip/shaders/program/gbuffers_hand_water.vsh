#include "/lib/all_the_libs.glsl"
#include "/generic/gbuffers.vsh"

void main() {
  init_generic();
}
