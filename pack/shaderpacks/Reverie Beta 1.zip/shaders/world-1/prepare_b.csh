#version 460 compatibility
#define DIMENSION_NETHER

#include "/program/prepare_b.csh"