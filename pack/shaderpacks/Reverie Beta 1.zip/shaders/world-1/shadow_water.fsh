#version 460 compatibility
#define DIMENSION_NETHER

#include "/program/shadow_water.fsh"