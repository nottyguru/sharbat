#version 460 compatibility
#define DIMENSION_END

#include "/program/shadow_water.fsh"