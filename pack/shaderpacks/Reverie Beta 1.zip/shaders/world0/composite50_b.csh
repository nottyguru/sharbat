#version 460 compatibility
#define DIMENSION_OVERWORLD

#include "/program/composite50_b.csh"